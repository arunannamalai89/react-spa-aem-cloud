const ALAPP = {
    global: {
        breakpoints: {
            mobile: 'xs',
            tabletP: 'sm',
            tabletL: 'md',
            desktop: 'lg'
        }
    }
}
export default ALAPP;