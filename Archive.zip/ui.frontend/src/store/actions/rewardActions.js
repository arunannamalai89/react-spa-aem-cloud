import { SET_REWARD_CODE } from "../constants";

export const openModal = () => ({
  type: SET_REWARD_CODE
})