import { OPEN_MODAL } from "../constants";

export const openModal = () => ({
  type: OPEN_MODAL
})