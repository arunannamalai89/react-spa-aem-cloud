self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a27ec9d996841442fd8dcbbadd4aa434",
    "url": "./index.html"
  },
  {
    "revision": "05df8d6fa836bdd062d1",
    "url": "./static/css/main.fd22afae.chunk.css"
  },
  {
    "revision": "701219ac306a536425ed",
    "url": "./static/js/2.486ae943.chunk.js"
  },
  {
    "revision": "750d13c8b846bb419c33139e1f368a29",
    "url": "./static/js/2.486ae943.chunk.js.LICENSE.txt"
  },
  {
    "revision": "05df8d6fa836bdd062d1",
    "url": "./static/js/main.9a99da98.chunk.js"
  },
  {
    "revision": "8f00c1dee87b44cfcfea",
    "url": "./static/js/runtime-main.e36f1888.js"
  },
  {
    "revision": "19a5bdabd660fde16554c866e650eadc",
    "url": "./static/media/icon-back.19a5bdab.svg"
  }
]);